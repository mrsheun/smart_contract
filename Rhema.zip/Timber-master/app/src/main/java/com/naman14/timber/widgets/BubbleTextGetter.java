package com.naman14.timber.widgets;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}